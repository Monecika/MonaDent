create function initialize_patient_dental_chart() returns trigger
    language plpgsql
as
$$
DECLARE
    patient_age INTEGER;
BEGIN
    IF NEW.date_of_birth > CURRENT_DATE THEN
        RAISE EXCEPTION 'Date of birth cannot be in the future'
            USING ERRCODE = '22007';
    END IF;

    patient_age := EXTRACT(YEAR FROM age(CURRENT_DATE, NEW.date_of_birth));

    IF patient_age <= 5 THEN
        -- Full primary dentition
        INSERT INTO patient_teeth (patient_id, tooth_number, tooth_type, status, presence_status)
        SELECT NEW.id, q.quadrant * 10 + p.position, 'PRIMARY', 'NOT_ASSESSED', 'UNKNOWN'
        FROM generate_series(5, 8) AS q(quadrant)
                 CROSS JOIN generate_series(1, 5) AS p(position);
    ELSIF patient_age <= 9 THEN
        -- Mixed dentition: primary canines/molars (positions 3-5) + first permanent incisors and molars
        INSERT INTO patient_teeth (patient_id, tooth_number, tooth_type, status, presence_status)
        SELECT NEW.id, q.quadrant * 10 + p.position, 'PRIMARY', 'NOT_ASSESSED', 'UNKNOWN'
        FROM generate_series(5, 8) AS q(quadrant)
                 CROSS JOIN (VALUES (3), (4), (5)) AS p(position);

        INSERT INTO patient_teeth (patient_id, tooth_number, tooth_type, status, presence_status)
        SELECT NEW.id, q.quadrant * 10 + p.position, 'PERMANENT', 'NOT_ASSESSED', 'UNKNOWN'
        FROM generate_series(1, 4) AS q(quadrant)
                 CROSS JOIN (VALUES (1), (2), (6)) AS p(position);
    ELSIF patient_age <= 17 THEN
        -- Permanent teeth without wisdom teeth
        INSERT INTO patient_teeth (patient_id, tooth_number, tooth_type, status, presence_status)
        SELECT NEW.id, q.quadrant * 10 + p.position, 'PERMANENT', 'NOT_ASSESSED', 'UNKNOWN'
        FROM generate_series(1, 4) AS q(quadrant)
                 CROSS JOIN generate_series(1, 7) AS p(position);
    ELSE
        -- Full permanent dentition
        INSERT INTO patient_teeth (patient_id, tooth_number, tooth_type, status, presence_status)
        SELECT NEW.id, q.quadrant * 10 + p.position, 'PERMANENT', 'NOT_ASSESSED', 'UNKNOWN'
        FROM generate_series(1, 4) AS q(quadrant)
                 CROSS JOIN generate_series(1, 8) AS p(position);
    END IF;

    RETURN NEW;
END;
$$;

alter function initialize_patient_dental_chart() owner to mona;

